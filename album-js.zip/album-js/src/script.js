//Array para las imagenes //

const imagenes = [ "https://cdn.pixabay.com/photo/2016/07/26/18/58/cat-1543541_1280.jpg", 
"https://cdn.pixabay.com/photo/2015/07/31/15/01/cat-869218_1280.jpg",         "https://cdn.pixabay.com/photo/2017/03/17/12/06/cat-2151382_1280.jpg",
"https://cdn.pixabay.com/photo/2015/07/31/15/00/cat-869204_1280.jpg",
"https://cdn.pixabay.com/photo/2017/05/14/17/40/cat-2312627_1280.jpg" 
];

//Seleccion de elementos//

const boton = document.getElementById("btn-cambiar");
const imageCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

let indice = 0;

boton.addEventListener("click", () => {
  indice++;

  if (indice >= imagenes.length) {
    indice = 0;
  }

  // Cambiar la imagen
  imageCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});
  
  
