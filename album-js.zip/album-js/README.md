# Album JS

A Pen created on CodePen.

Original URL: [https://codepen.io/SOFIA-MONTSERRAT-FERNANDEZZUNIGA/pen/EaVMrQj](https://codepen.io/SOFIA-MONTSERRAT-FERNANDEZZUNIGA/pen/EaVMrQj).

